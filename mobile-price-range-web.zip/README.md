# Mobile Price Range Classification — Web Application

A VS Code + GitHub ready implementation of the workflow described in the project PPT:

**Mobile specifications → Data preprocessing → Feature selection → Decision Tree → Price range classification → Model evaluation → Feature importance**

The PPT describes a 2,000-record, 20-feature dataset, four classes, an 80:20 split, and a Decision Tree using Gini with `max_depth=8` and `random_state=42`. It reports 85.25% test accuracy. The web application below trains the model locally and displays the **actual metrics produced by your installed environment/dataset**, rather than hard-coding the reported result.

## 1. Requirements

Install:

- Python 3.10+
- VS Code
- Git
- A browser

## 2. Dataset

Use the standard **Mobile Price Classification** `train.csv` containing these columns:

`battery_power, blue, clock_speed, dual_sim, fc, four_g, int_memory, m_dep, mobile_wt, n_cores, pc, px_height, px_width, ram, sc_h, sc_w, talk_time, three_g, touch_screen, wifi, price_range`

If you do not already have the dataset locally, the project now generates a fallback training CSV automatically for demo use so the website can run immediately in this environment.

```text
data/train.csv
```

Do not commit the dataset if you do not have permission to redistribute it.

## 3. Create the Python environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If PowerShell blocks activation, use:

```powershell
.venv\Scripts\activate.bat
```

## 4. Train the model

From the project root:

```powershell
python backend/train_model.py
```

This creates:

```text
model/model.joblib
model/metrics.json
model/feature_importance.json
```

## 5. Start the backend

```powershell
python backend/app.py
```

Backend:

```text
http://127.0.0.1:5000
```

## 6. Start the frontend

Open a second VS Code terminal:

```powershell
cd frontend
python -m http.server 5500
```

Open:

```text
http://127.0.0.1:5500
```

You now have:

1. Input form
2. API request
3. Decision Tree prediction
4. Price-range result
5. Class probabilities
6. Accuracy / precision / recall / F1
7. Feature-importance display

## 7. GitHub workflow

```powershell
git init
git add .
git commit -m "Initial mobile price range classification web app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mobile-price-range-classification.git
git push -u origin main
```

Create the GitHub repository first, then replace `YOUR_USERNAME` with your GitHub username.

## 8. Recommended repository structure

```text
mobile-price-range-classification/
│
├── backend/
│   ├── __init__.py
│   ├── app.py
│   └── train_model.py
│
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
├── data/
│   └── train.csv              # keep local / add only if allowed
│
├── model/
│   ├── model.joblib            # generated locally
│   ├── metrics.json            # generated locally
│   └── feature_importance.json # generated locally
│
├── .gitignore
├── requirements.txt
└── README.md
```

## 9. Project demonstration flow

For your project/demo:

**Start**
→ Enter mobile name or specifications
→ Resolve a known phone profile
→ Validate input
→ Send JSON to Flask API
→ Load trained Decision Tree
→ Predict one of 4 classes
→ Show confidence/probabilities
→ Show model metrics
→ Show feature importance
→ **End**

The app also supports a faster workflow: type a phone name such as `iPhone 15 Pro` or `Galaxy S24 Ultra`, and the backend returns the matching technical specs before running the prediction model.

The four output classes are:

- 0 — Low Cost
- 1 — Medium Cost
- 2 — High Cost
- 3 — Very High Cost

## 10. Important

The PPT's reported 85.25% accuracy is a project result. Your website should not fake that number. Train the model and let the dashboard show the metric returned by your actual run.
