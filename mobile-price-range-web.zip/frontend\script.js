const API = "http://127.0.0.1:5000";

const sample = {
  battery_power: 1800, blue: 1, clock_speed: 2.2, dual_sim: 1, fc: 8,
  four_g: 1, int_memory: 64, m_dep: 0.7, mobile_wt: 145, n_cores: 8,
  pc: 20, px_height: 1200, px_width: 1920, ram: 3500, sc_h: 16,
  sc_w: 8, talk_time: 14, three_g: 1, touch_screen: 1, wifi: 1
};

function setForm(data) {
  Object.entries(data).forEach(([key, value]) => {
    const el = document.querySelector(`[name="${key}"]`);
    if (el) el.value = value;
  });
}

function collectForm() {
  const data = {};
  new FormData(document.getElementById("predictionForm")).forEach((value, key) => {
    const num = Number(value);
    data[key] = Number.isFinite(num) ? num : value;
  });
  return data;
}

function redirectToResultPage(resultData) {
  localStorage.setItem("mobilePriceResult", JSON.stringify(resultData));
  window.location.href = "result.html";
}

function buildExplanation(priceRange, specs) {
  const values = { ...specs };

  const scoreSignals = [
    { name: "battery power", value: Number(values.battery_power || 0), high: 4000, low: 1800 },
    { name: "RAM", value: Number(values.ram || 0), high: 8000, low: 2000 },
    { name: "internal memory", value: Number(values.int_memory || 0), high: 128, low: 16 },
    { name: "camera", value: Number(values.pc || 0), high: 40, low: 8 },
    { name: "screen size", value: Number(values.sc_h || 0), high: 7, low: 4 },
    { name: "mobile weight", value: Number(values.mobile_wt || 0), high: 180, low: 120 }
  ];

  const positive = scoreSignals.filter((item) => item.value >= item.high).length;
  const lowPositive = scoreSignals.filter((item) => item.value <= item.low).length;

  if (priceRange === "High Cost" || priceRange === "Very High Cost") {
    const reasons = [];
    if (Number(values.ram || 0) >= 8000) reasons.push("RAM is high, which typically indicates a premium device.");
    if (Number(values.battery_power || 0) >= 4000) reasons.push("Battery capacity is large, which supports a higher price bracket.");
    if (Number(values.pc || 0) >= 40 || Number(values.fc || 0) >= 12) reasons.push("Camera specs are strong for flagship-level pricing.");
    if (Number(values.sc_h || 0) >= 7) reasons.push("Display size and premium screen dimensions support a higher class.");
    if (reasons.length === 0) reasons.push("The phone has strong overall specs across memory, battery, and display components.");
    return `${reasons.slice(0, 3).join(" ")} Overall, ${positive} key premium signals are above the high-end threshold, which strongly matches ${priceRange}.`;
  }

  if (priceRange === "Low Cost") {
    const reasons = [];
    if (Number(values.ram || 0) <= 2000) reasons.push("RAM is low, which is common for budget phones.");
    if (Number(values.battery_power || 0) <= 1800) reasons.push("Battery capacity is modest, matching a lower price tier.");
    if (Number(values.int_memory || 0) <= 16) reasons.push("Storage is limited, which reduces the value expectation.");
    if (Number(values.pc || 0) <= 8) reasons.push("Camera capability is basic compared with mid- and premium-range phones.");
    if (reasons.length === 0) reasons.push("The phone has a lower-spec profile across its main features and falls into the entry-level range.");
    return `${reasons.slice(0, 3).join(" ")} Overall, ${lowPositive} key budget signals are below the low-end threshold, which matches ${priceRange}.`;
  }

  const reasons = [];
  if (Number(values.ram || 0) >= 4000) reasons.push("RAM is mid-to-high, giving it a solid performance profile.");
  if (Number(values.battery_power || 0) >= 2500) reasons.push("Battery size is adequate for a mid-range device.");
  if (Number(values.int_memory || 0) >= 32) reasons.push("Storage is acceptable for everyday use and mainstream applications.");
  if (reasons.length === 0) reasons.push("The phone has a balanced profile between affordability and capability.");
  return `${reasons.slice(0, 3).join(" ")} This combination places it in the ${priceRange} category because it sits between the budget and premium ranges.`;
}

async function submitPrediction() {
  const error = document.getElementById("error");
  error.textContent = "";

  try {
    const payload = collectForm();
    const res = await fetch(`${API}/api/predict`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Prediction failed");

    const resolvedName = document.getElementById("phoneLookup").value.trim() || "Manual input";
    const resultData = {
      mobileName: resolvedName,
      price_range: data.price_range,
      confidence: data.confidence,
      class_probabilities: data.class_probabilities,
      explanation: buildExplanation(data.price_range, payload),
      timestamp: new Date().toISOString()
    };

    redirectToResultPage(resultData);
  } catch (err) {
    error.textContent = err.message;
  }
}

async function loadModelInfo() {
  try {
    const res = await fetch(`${API}/api/model-info`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Model unavailable");

    const m = data.metrics;
    document.getElementById("accuracy").textContent = `${m.accuracy}%`;
    document.getElementById("records").textContent = m.records;
    document.getElementById("split").textContent = `${m.train_records} / ${m.test_records}`;
    document.getElementById("metricAccuracy").textContent = `${m.accuracy}%`;
    document.getElementById("precision").textContent = `${m.precision_macro}%`;
    document.getElementById("recall").textContent = `${m.recall_macro}%`;
    document.getElementById("f1").textContent = `${m.f1_macro}%`;

    const features = document.getElementById("features");
    features.innerHTML = "";
    data.feature_importance.slice(0, 6).forEach(item => {
      const row = document.createElement("div");
      row.className = "feature-row";
      row.innerHTML = `
        <div class="feature-meta"><span>${item.feature}</span><b>${(item.importance * 100).toFixed(1)}%</b></div>
        <div class="feature-bar"><i style="width:${Math.max(item.importance * 100, 1)}%"></i></div>
      `;
      features.appendChild(row);
    });
  } catch (err) {
    document.getElementById("error").textContent = err.message;
  }
}

async function loadSuggestions() {
  try {
    const res = await fetch(`${API}/api/mobile/catalog`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Unable to load suggestions");

    const datalist = document.getElementById("phoneSuggestions");
    datalist.innerHTML = "";
    data.models.forEach((name) => {
      const option = document.createElement("option");
      option.value = name;
      datalist.appendChild(option);
    });
  } catch (err) {
    console.warn(err.message);
  }
}

const predictionForm = document.getElementById("predictionForm");
if (predictionForm) {
  document.getElementById("sampleBtn").addEventListener("click", () => setForm(sample));

  document.getElementById("lookupBtn").addEventListener("click", async () => {
    const query = document.getElementById("phoneLookup").value.trim();
    const error = document.getElementById("error");
    const summary = document.getElementById("lookupSummary");
    if (!query) {
      error.textContent = "Enter a mobile name first.";
      summary.classList.add("hidden");
      return;
    }

    try {
      const res = await fetch(`${API}/api/mobile/search?name=${encodeURIComponent(query)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Phone lookup failed");

      setForm(data.specs);
      summary.textContent = `Loaded specs for ${data.name} from the phone dataset.`;
      summary.classList.remove("hidden");
      document.getElementById("rangeLabel").textContent = data.name;
      error.textContent = "";
      const resultData = {
        mobileName: data.name,
        source: "lookup",
        specs: data.specs
      };
      localStorage.setItem("mobileLookupMeta", JSON.stringify(resultData));
    } catch (err) {
      summary.textContent = `No phone match found for "${query}".`;
      summary.classList.remove("hidden");
      error.textContent = err.message;
    }
  });

  document.getElementById("phoneLookup").addEventListener("input", () => {
    const query = document.getElementById("phoneLookup").value.trim();
    if (query.length >= 2) {
      const datalist = document.getElementById("phoneSuggestions");
      const currentValues = Array.from(datalist.options).map((o) => o.value.toLowerCase());
      if (!currentValues.length) return;
      const filtered = currentValues.filter((name) => name.includes(query.toLowerCase()));
      if (filtered.length > 0) {
        datalist.innerHTML = "";
        filtered.slice(0, 8).forEach((name) => {
          const option = document.createElement("option");
          option.value = name;
          datalist.appendChild(option);
        });
      }
    }
  });

  document.getElementById("phoneLookup").addEventListener("keydown", async (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      document.getElementById("lookupBtn").click();
    }
  });

  predictionForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    await submitPrediction();
  });

  loadModelInfo();
  loadSuggestions();
}
