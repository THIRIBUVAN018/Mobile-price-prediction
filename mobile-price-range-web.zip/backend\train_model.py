from __future__ import annotations

import json
import sys
import types
from pathlib import Path

import numpy as np
import pandas as pd
import joblib

ROOT = Path(__file__).resolve().parents[1]
backend_package = sys.modules.setdefault("backend", types.ModuleType("backend"))
backend_package.__path__ = [str(ROOT / "backend")]
sys.modules["backend.train_model"] = sys.modules.setdefault(__name__, sys.modules[__name__])

DATA_PATH = ROOT / "data" / "train.csv"
MODEL_DIR = ROOT / "model"
MODEL_DIR.mkdir(exist_ok=True)

FEATURES = [
    "battery_power", "blue", "clock_speed", "dual_sim", "fc", "four_g",
    "int_memory", "m_dep", "mobile_wt", "n_cores", "pc", "px_height",
    "px_width", "ram", "sc_h", "sc_w", "talk_time", "three_g",
    "touch_screen", "wifi"
]

LABELS = {
    0: "Low Cost",
    1: "Medium Cost",
    2: "High Cost",
    3: "Very High Cost"
}


def gini_score(labels):
    if len(labels) == 0:
        return 0.0
    counts = np.bincount(labels.astype(int), minlength=max(int(labels.max()) + 1, 1))
    probabilities = counts / len(labels)
    return 1.0 - float(np.sum(probabilities ** 2))


class SimpleDecisionTreeClassifier:
    def __init__(self, max_depth=8, min_samples_split=2, random_state=42):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.random_state = random_state
        self.root_ = None
        self.classes_ = None
        self.feature_importances_ = None

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=int)
        self.classes_ = np.array(sorted(set(y.tolist())))
        self.feature_importances_ = np.zeros(X.shape[1], dtype=float)
        self.root_ = self._build_tree(X, y, depth=0)
        total_importance = self.feature_importances_.sum()
        if total_importance > 0:
            self.feature_importances_ /= total_importance
        return self

    def _build_tree(self, X, y, depth):
        if len(np.unique(y)) == 1 or depth >= self.max_depth or len(y) < self.min_samples_split:
            return self._leaf_node(y)

        best_gain = 0.0
        best_split = None
        parent_gini = gini_score(y)

        for feature_idx in range(X.shape[1]):
            values = np.unique(X[:, feature_idx])
            if len(values) < 2:
                continue
            thresholds = (values[:-1] + values[1:]) / 2.0
            for threshold in thresholds:
                left_mask = X[:, feature_idx] <= threshold
                right_mask = ~left_mask
                if not left_mask.any() or not right_mask.any():
                    continue
                left_y = y[left_mask]
                right_y = y[right_mask]
                weighted_gini = (
                    (len(left_y) / len(y)) * gini_score(left_y)
                    + (len(right_y) / len(y)) * gini_score(right_y)
                )
                gain = parent_gini - weighted_gini
                if gain > best_gain:
                    best_gain = gain
                    best_split = {
                        "feature_idx": feature_idx,
                        "threshold": float(threshold),
                        "left_mask": left_mask,
                        "right_mask": right_mask,
                        "left_y": left_y,
                        "right_y": right_y,
                    }

        if best_split is None:
            return self._leaf_node(y)

        self.feature_importances_[best_split["feature_idx"]] += best_gain

        node = {
            "feature_idx": best_split["feature_idx"],
            "threshold": best_split["threshold"],
            "left": self._build_tree(X[best_split["left_mask"]], best_split["left_y"], depth + 1),
            "right": self._build_tree(X[best_split["right_mask"]], best_split["right_y"], depth + 1),
            "is_leaf": False,
        }
        return node

    def _leaf_node(self, y):
        counts = np.bincount(y.astype(int), minlength=int(max(y.max(), 0)) + 1)
        probabilities = counts / max(len(y), 1)
        label = int(np.argmax(probabilities)) if probabilities.size else 0
        return {
            "is_leaf": True,
            "prediction": label,
            "probabilities": {int(cls): float(prob) for cls, prob in enumerate(probabilities) if prob > 0},
        }

    def _predict_one(self, row, node):
        if node["is_leaf"]:
            return node["prediction"]
        if row[node["feature_idx"]] <= node["threshold"]:
            return self._predict_one(row, node["left"])
        return self._predict_one(row, node["right"])

    def _predict_distribution_one(self, row, node):
        if node["is_leaf"]:
            return node["probabilities"]
        if row[node["feature_idx"]] <= node["threshold"]:
            return self._predict_distribution_one(row, node["left"])
        return self._predict_distribution_one(row, node["right"])

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        return np.array([self._predict_one(row, self.root_) for row in X])

    def predict_proba(self, X):
        X = np.asarray(X, dtype=float)
        prob_rows = []
        for row in X:
            dist = self._predict_distribution_one(row, self.root_)
            full = np.zeros(len(self.classes_), dtype=float)
            for cls_index, value in dist.items():
                cls_pos = int(np.where(self.classes_ == cls_index)[0][0]) if cls_index in self.classes_ else 0
                full[cls_pos] = value
            prob_rows.append(full)
        return np.array(prob_rows)


SimpleDecisionTreeClassifier.__module__ = "backend.train_model"


def generate_dataset(rows=2200, random_seed=42):
    rng = np.random.default_rng(random_seed)
    data = {
        "battery_power": rng.integers(500, 2001, size=rows),
        "blue": rng.integers(0, 2, size=rows),
        "clock_speed": rng.uniform(0.5, 3.5, size=rows),
        "dual_sim": rng.integers(0, 2, size=rows),
        "fc": rng.integers(0, 21, size=rows),
        "four_g": rng.integers(0, 2, size=rows),
        "int_memory": rng.integers(2, 129, size=rows),
        "m_dep": rng.uniform(0.1, 1.0, size=rows),
        "mobile_wt": rng.integers(80, 220, size=rows),
        "n_cores": rng.integers(1, 9, size=rows),
        "pc": rng.integers(0, 21, size=rows),
        "px_height": rng.integers(100, 2001, size=rows),
        "px_width": rng.integers(200, 4001, size=rows),
        "ram": rng.integers(256, 4097, size=rows),
        "sc_h": rng.integers(3, 20, size=rows),
        "sc_w": rng.integers(2, 16, size=rows),
        "talk_time": rng.integers(2, 21, size=rows),
        "three_g": rng.integers(0, 2, size=rows),
        "touch_screen": rng.integers(0, 2, size=rows),
        "wifi": rng.integers(0, 2, size=rows),
    }

    ram_score = data["ram"] / 4096.0
    battery_score = data["battery_power"] / 2000.0
    camera_score = ((data["pc"] + data["fc"]) / 40.0)
    storage_score = data["int_memory"] / 128.0
    display_score = ((data["px_width"] * data["px_height"]) / 8_000_000.0)
    weighted_score = (
        ram_score * 0.42
        + battery_score * 0.18
        + camera_score * 0.1
        + storage_score * 0.12
        + display_score * 0.11
        + (data["n_cores"] / 8.0) * 0.07
    )
    data["price_range"] = np.clip((weighted_score * 4).astype(int), 0, 3)
    return pd.DataFrame(data)


def prepare_dataset():
    if DATA_PATH.exists():
        data = pd.read_csv(DATA_PATH)
    else:
        DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = generate_dataset()
        data.to_csv(DATA_PATH, index=False)
        print(f"Generated fallback dataset at {DATA_PATH}")

    missing = [column for column in FEATURES + ["price_range"] if column not in data.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    data = data.drop_duplicates().copy()
    data = data.dropna(subset=FEATURES + ["price_range"])
    return data


def train_test_split_stratified(X, y, test_size=0.2, random_state=42):
    rng = np.random.default_rng(random_state)
    train_idx, test_idx = [], []
    for label in np.unique(y):
        label_indices = np.where(y == label)[0]
        rng.shuffle(label_indices)
        split_point = max(1, int(round(len(label_indices) * (1 - test_size))))
        train_idx.extend(label_indices[:split_point])
        test_idx.extend(label_indices[split_point:])
    return X.iloc[train_idx].reset_index(drop=True), X.iloc[test_idx].reset_index(drop=True), y.iloc[train_idx].reset_index(drop=True), y.iloc[test_idx].reset_index(drop=True)


def accuracy_score(y_true, y_pred):
    return float(np.mean(np.asarray(y_true) == np.asarray(y_pred))) * 100.0


def precision_score(y_true, y_pred, average="macro"):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    labels = np.unique(np.concatenate([y_true, y_pred]))
    precisions = []
    for cls in labels:
        true_positive = np.sum((y_true == cls) & (y_pred == cls))
        predicted_positive = np.sum(y_pred == cls)
        precisions.append(0.0 if predicted_positive == 0 else true_positive / predicted_positive)
    return float(np.mean(precisions)) * 100.0 if average == "macro" else float(np.mean(precisions))


def recall_score(y_true, y_pred, average="macro"):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    labels = np.unique(np.concatenate([y_true, y_pred]))
    recalls = []
    for cls in labels:
        true_positive = np.sum((y_true == cls) & (y_pred == cls))
        actual_positive = np.sum(y_true == cls)
        recalls.append(0.0 if actual_positive == 0 else true_positive / actual_positive)
    return float(np.mean(recalls)) * 100.0 if average == "macro" else float(np.mean(recalls))


def f1_score(y_true, y_pred, average="macro"):
    precision = precision_score(y_true, y_pred, average)
    recall = recall_score(y_true, y_pred, average)
    return (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0


def confusion_matrix(y_true, y_pred, labels=None):
    if labels is None:
        labels = np.unique(np.concatenate([np.asarray(y_true), np.asarray(y_pred)]))
    labels = np.asarray(labels)
    matrix = np.zeros((len(labels), len(labels)), dtype=int)
    for actual, predicted in zip(y_true, y_pred):
        actual_idx = int(np.where(labels == actual)[0][0])
        predicted_idx = int(np.where(labels == predicted)[0][0])
        matrix[actual_idx, predicted_idx] += 1
    return matrix.tolist()


def train():
    data = prepare_dataset()
    X = data[FEATURES]
    y = data["price_range"].astype(int)

    X_train, X_test, y_train, y_test = train_test_split_stratified(X, y, test_size=0.20, random_state=42)

    model = SimpleDecisionTreeClassifier(max_depth=8, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    metrics = {
        "records": int(len(data)),
        "train_records": int(len(X_train)),
        "test_records": int(len(X_test)),
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 2),
        "precision_macro": round(float(precision_score(y_test, y_pred, average="macro")), 2),
        "recall_macro": round(float(recall_score(y_test, y_pred, average="macro")), 2),
        "f1_macro": round(float(f1_score(y_test, y_pred, average="macro")), 2),
        "confusion_matrix": confusion_matrix(y_test, y_pred, labels=np.array([0, 1, 2, 3])),
        "class_labels": [LABELS[i] for i in range(4)]
    }

    importance = [
        {"feature": feature, "importance": round(float(value), 4)}
        for feature, value in zip(FEATURES, model.feature_importances_)
    ]
    importance.sort(key=lambda item: item["importance"], reverse=True)

    joblib.dump({"model": model, "features": FEATURES, "labels": LABELS}, MODEL_DIR / "model.joblib")
    (MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2))
    (MODEL_DIR / "feature_importance.json").write_text(json.dumps(importance, indent=2))

    print("Training complete.")
    print(json.dumps(metrics, indent=2))
    print("Top features:", importance[:6])


if __name__ == "__main__":
    train()
