import sys
import re
import difflib
import sys
from pathlib import Path
import json
import joblib
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
MODEL_DIR = ROOT / "model"

app = Flask(__name__)
CORS(app)

FEATURES = [
    "battery_power", "blue", "clock_speed", "dual_sim", "fc", "four_g",
    "int_memory", "m_dep", "mobile_wt", "n_cores", "pc", "px_height",
    "px_width", "ram", "sc_h", "sc_w", "talk_time", "three_g",
    "touch_screen", "wifi"
]

PHONE_CATALOG_PATH = ROOT / "data" / "phones.csv"


def normalize_name(value):
    return re.sub(r"[^a-z0-9]+", " ", (value or "").lower()).strip()


def load_phone_catalog():
    catalog = {}
    path = PHONE_CATALOG_PATH
    if not path.exists():
        return catalog

    df = pd.read_csv(path)
    required = ["brand", "model"] + FEATURES
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"phones.csv is missing required columns: {missing}")

    for row in df.to_dict(orient="records"):
        full_name = f"{row['brand']} {row['model']}".strip()
        spec = {feature: row[feature] for feature in FEATURES}
        spec["name"] = full_name
        catalog[normalize_name(full_name)] = spec

    return catalog


PHONE_CATALOG = load_phone_catalog()

model_bundle = None
metrics = None
importance = None


def find_phone_by_name(query):
    normalized_query = normalize_name(query)
    if not normalized_query:
        return None

    exact = PHONE_CATALOG.get(normalized_query)
    if exact:
        return exact

    candidates = list(PHONE_CATALOG.keys())
    close = difflib.get_close_matches(normalized_query, candidates, n=1, cutoff=0.4)
    if close:
        return PHONE_CATALOG[close[0]]

    for key, profile in PHONE_CATALOG.items():
        if normalized_query in key or key in normalized_query:
            return profile

    return None

def load_artifacts():
    global model_bundle, metrics, importance
    model_path = MODEL_DIR / "model.joblib"

    if not model_path.exists():
        return False

    model_bundle = joblib.load(model_path)
    metrics = json.loads((MODEL_DIR / "metrics.json").read_text())
    importance = json.loads((MODEL_DIR / "feature_importance.json").read_text())
    return True

load_artifacts()

@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "model_loaded": model_bundle is not None
    })

@app.get("/api/model-info")
def model_info():
    if model_bundle is None:
        return jsonify({
            "error": "Model is not trained yet. Run: python backend/train_model.py"
        }), 503

    return jsonify({
        "metrics": metrics,
        "feature_importance": importance,
        "features": model_bundle["features"]
    })

@app.get("/api/mobile/catalog")
def mobile_catalog():
    models = sorted(PHONE_CATALOG.keys())
    return jsonify({"models": [PHONE_CATALOG[name]["name"] for name in models]})


@app.get("/api/mobile/search")
def mobile_search():
    query = (request.args.get("name") or "").strip()
    if not query:
        return jsonify({"error": "Enter a mobile name to search."}), 400

    phone = find_phone_by_name(query)
    if phone is None:
        return jsonify({
            "error": f"No matching phone found for '{query}'. Try a known model like 'iPhone 15 Pro' or 'Galaxy S24 Ultra'."
        }), 404

    price_range = phone["name"]
    return jsonify({
        "name": phone["name"],
        "specs": {key: value for key, value in phone.items() if key != "name"},
        "price_range_hint": price_range
    })

@app.post("/api/predict")
def predict():
    if model_bundle is None:
        return jsonify({
            "error": "Model is not trained yet. Run: python backend/train_model.py"
        }), 503

    payload = request.get_json(silent=True) or {}
    features = model_bundle["features"]

    missing = [f for f in features if f not in payload]
    if missing:
        return jsonify({"error": f"Missing fields: {missing}"}), 400

    try:
        row = {f: float(payload[f]) for f in features}
    except (TypeError, ValueError):
        return jsonify({"error": "All specification values must be numeric."}), 400

    X = pd.DataFrame([row], columns=features)
    prediction = int(model_bundle["model"].predict(X)[0])
    probabilities = model_bundle["model"].predict_proba(X)[0]

    label = model_bundle["labels"].get(prediction, str(prediction))
    confidence = round(float(max(probabilities)) * 100, 2)

    class_probabilities = {
        model_bundle["labels"][int(cls)]: round(float(prob) * 100, 2)
        for cls, prob in zip(model_bundle["model"].classes_, probabilities)
    }

    return jsonify({
        "class_id": prediction,
        "price_range": label,
        "confidence": confidence,
        "class_probabilities": class_probabilities
    })

@app.get("/")
def root():
    return send_from_directory(str(ROOT / "frontend"), "index.html")

@app.get("/result.html")
def result_page():
    return send_from_directory(str(ROOT / "frontend"), "result.html")

@app.get("/<path:filename>")
def frontend_files(filename):
    if filename.endswith(".css") or filename.endswith(".js") or filename.endswith(".html"):
        return send_from_directory(str(ROOT / "frontend"), filename)
    return jsonify({"error": "Not found"}), 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
